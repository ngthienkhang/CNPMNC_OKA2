import React from 'react';
import logo from './logo.svg';
import './App.css';
import "bootstrap/dist/css/bootstrap.css";
import {Button,Row, Col} from 'react-bootstrap';
import Menu from './components/menu';
import Leftside from "./components/Leftside";
import Rightside from "./components/Rightside";
function App() {
  return (
    <div className="App">     
     <Menu/>
     <Row className="landing">
       < Col> <Leftside/></Col>
       
       <Col> <Rightside/></Col>
     </Row>
    </div>
  );
}

export default App;
