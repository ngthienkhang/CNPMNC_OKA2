import React from 'react';
import {Image} from 'react-bootstrap';
const Rightside = () => {
    return (
        <div>
           <Image src="./img/10109.jpg" thumbnail  style={{border:"none"}}/>
        </div>
    )
}

export default Rightside
