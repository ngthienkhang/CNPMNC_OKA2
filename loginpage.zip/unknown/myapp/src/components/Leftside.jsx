import React from 'react';
import { Form, Button, FormText, NavLink} from 'react-bootstrap';
const Leftside = () => {
    return (
        <div>
            <br/>
            <br/>
            <br/>
            <Form style={{width:"80%", marginLeft:"10%", marginTop:"10%"}}>
            <Form.Group>
                <Form.Label>Username: </Form.Label>
                <Form.Control type="username" placeholder="Nhập tên đăng nhập..."/>
               
            </Form.Group>
            <Form.Group>
                <Form.Label>Password: </Form.Label>
                <Form.Control type="password" placeholder="Nhập mật khẩu..."/>              
            </Form.Group>                     
          
            <Button type="submit">Submit</Button>
            <br/>
            <br/>
            <NavLink>Chưa có tài khoản ? Đăng kí ngay</NavLink>
            </Form>
        </div>
    )
}

export default Leftside
